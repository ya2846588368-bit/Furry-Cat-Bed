Sponsoring
==========

You may sponsor the development of websockets through:

* `GitHub Sponsors`_
* `Open Collective`_
* :doc:`Tidelift <tidelift>`

.. _GitHub Sponsors: https://github.com/sponsors/python-websockets
.. _Open Collective: https://opencollective.com/websockets
