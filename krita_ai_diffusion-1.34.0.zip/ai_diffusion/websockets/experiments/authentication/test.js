var token = document.body.dataset.token;

const params = new URLSearchParams(window.location.search);
var user = params.get("user");
