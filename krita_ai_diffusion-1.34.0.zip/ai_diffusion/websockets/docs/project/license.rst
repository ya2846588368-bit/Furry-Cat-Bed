License
=======

.. include:: ../../LICENSE
